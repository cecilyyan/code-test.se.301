from django.test import TestCase
from .models import UserProfile, DataJson, Data
from django.contrib.auth.models import User


class SimpleTest(TestCase):

    @classmethod
    def setUpTestData(cls):

        # Set up non-modified objects used by all test methods
        UserProfile.objects.create(org='duke', telephone='12345')
        User.objects.creat(username='abc', password='123456', email='12345@duke.edu')
        DataJson.objects.creat(data={"data": '2-1', "degree": '30'})
        Data.obk=jects.creat(date='2-1', degree='30')

    def test_first_name_label(self):
        user = User.objects.get(pk=1)
        field_label = user._meta.get_field('username').verbose_name
        self.assertEquals(field_label, 'username')

