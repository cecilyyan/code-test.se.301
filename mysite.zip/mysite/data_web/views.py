from django.shortcuts import render, get_object_or_404
from django.contrib.auth.models import User
from .models import UserProfile, DataJson, Data
from django.contrib import auth
from .forms import RegistrationForm, LoginForm, ProfileForm, PwdChangeForm, DataInputForm
from django.http import HttpResponseRedirect
from django.urls import reverse

from django.contrib.auth.decorators import login_required
from django.views.decorators.csrf import csrf_exempt
import matplotlib.pyplot as plt
import json


def home(request):
    return render(request, 'data_web/home.html')


def register(request):
    if request.method == 'POST':

        form = RegistrationForm(request.POST)
        if form.is_valid():
            # get the data from form
            username = form.cleaned_data['username']
            email = form.cleaned_data['email']
            password = form.cleaned_data['password2']
            user = User.objects.create_user(username=username, password=password, email=email)
            # creat userprofile object
            user_profile = UserProfile(user=user)
            user_profile.save()

            return HttpResponseRedirect("/login/")

    else:
        form = RegistrationForm()

    return render(request, 'data_web/registration.html', {'form': form})


def login(request):
    if request.method == 'POST':
        form = LoginForm(request.POST)
        if form.is_valid():
            username = form.cleaned_data['username']
            password = form.cleaned_data['password']
            # check the password and username
            user = auth.authenticate(username=username, password=password)

            if user is not None and user.is_active:
                # login success
                auth.login(request, user)
                return HttpResponseRedirect(reverse('data_web:profile', args=[user.id]))

            else:
                # login fail
                  return render(request, 'data_web/login.html', {'form': form,
                               'message': 'Wrong password. Please try again.'})
    else:
        form = LoginForm()

    return render(request, 'data_web/login.html', {'form': form})


@login_required
def profile(request, pk):
    user = get_object_or_404(User, pk=pk)
    return render(request, 'data_web/profile.html', {'user': user})


@login_required
def profile_update(request, pk):
    user = get_object_or_404(User, pk=pk)
    user_profile = get_object_or_404(UserProfile, user=user)

    if request.method == "POST":
        form = ProfileForm(request.POST)
        # read the data in form and update the profile information
        if form.is_valid():
            user.first_name = form.cleaned_data['first_name']
            user.last_name = form.cleaned_data['last_name']
            user.save()

            user_profile.org = form.cleaned_data['org']
            user_profile.telephone = form.cleaned_data['telephone']
            user_profile.save()

            return HttpResponseRedirect(reverse('data_web:profile', args=[user.id]))
    else:
        # no change
        default_data = {'first_name': user.first_name, 'last_name': user.last_name,
                        'org': user_profile.org, 'telephone': user_profile.telephone, }
        form = ProfileForm(default_data)

    return render(request, 'data_web/profile_update.html', {'form': form, 'user': user})


def logout(request):
    auth.logout(request)
    return HttpResponseRedirect("/")


@login_required
def pwd_change(request, pk):
    user = get_object_or_404(User, pk=pk)

    if request.method == "POST":
        form = PwdChangeForm(request.POST)

        if form.is_valid():

            password = form.cleaned_data['old_password']
            username = user.username
            # authenticate the password
            user = auth.authenticate(username=username, password=password)

            if user is not None and user.is_active:
                new_password = form.cleaned_data['password2']
                user.set_password(new_password)
                user.save()
                return HttpResponseRedirect("data_web/login/")

            else:
                return render(request, 'data_web/pwd_change.html', {'form': form,
        'user': user, 'message': 'Old password is wrong. Try again'})
    else:
        form = PwdChangeForm()

    return render(request, 'data_web/pwd_change.html', {'form': form, 'user': user})


@csrf_exempt
def data_input(request, pk):
    if request.method == 'POST':
        # read the data in form and store the data to database
        form = DataInputForm(request.POST)
        if form.is_valid():
            date = form.cleaned_data['date']
            degree = form.cleaned_data['degree']

            data_db = Data(date=date, degree=degree)
            data_db.save()
            # store the json data into database
            data_db_json = DataJson(data={"date": date, "degree": degree})
            data_db_json.save()
            return render(request, 'data_web/input_data.html', {'form': form, 'message': 'success add data'})
    else:
        form = DataInputForm()

    return render(request, 'data_web/input_data.html', {'form': form})


def showdata(request, pk):
    if request.method == 'GET':
        # get all json data from database
        json_set = DataJson.objects.all()
        if json_set is None:
            print("none json")
        x = []
        y = []
        jsondata = []
        for one_json in json_set:
            print(one_json.data)
            x_value = one_json.data["date"]
            y_value = one_json.data["degree"]
            x.append(x_value)
            y.append(int(y_value))
            jsondata.append(one_json.data)

        # draw the bar chart

        # plotting the points
        plt.plot(x, y)
        # naming the x axis
        plt.xlabel('date')
        # naming the y axis
        plt.ylabel('temperature')

        # giving a title to my graph
        plt.title('temperature histogram!')

        plt.savefig('data_web/static/plot.jpg')
        # function to show the plot
        return render(request, 'data_web/showdata.html', {'json': jsondata})
    return render(request, 'data_web/showdata.html')





