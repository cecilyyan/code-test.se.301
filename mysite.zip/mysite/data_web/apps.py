from django.apps import AppConfig


class DataWebConfig(AppConfig):
    name = 'data_web'
